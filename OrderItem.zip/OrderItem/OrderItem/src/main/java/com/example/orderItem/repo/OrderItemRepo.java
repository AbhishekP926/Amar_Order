/**
 * 
 */
package com.example.orderItem.repo;


import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.orderItem.Dao.OrderItem;

/**
 * @author 34798
 *
 */
@Repository
public interface OrderItemRepo extends CrudRepository<OrderItem, Long> {

	Optional<OrderItem> findByproductCode(String pProductCode);
}
