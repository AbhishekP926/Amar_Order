/**
 * 
 */
package com.example.orderItem.Dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 34798
 *
 */
@Getter
@Setter
public class OrderItemRequest {
	private String productName;
	private String productCode;
	private int quantity;
}
