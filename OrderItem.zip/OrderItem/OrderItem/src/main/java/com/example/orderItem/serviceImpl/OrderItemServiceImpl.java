package com.example.orderItem.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderItem.Dao.OrderItem;
import com.example.orderItem.Dto.OrderItemDto;
import com.example.orderItem.Dto.OrderItemRequest;
import com.example.orderItem.repo.OrderItemRepo;
import com.example.orderItem.service.OrderItemService;

@Service
public class OrderItemServiceImpl implements OrderItemService {

	@Autowired
	private OrderItemRepo repo;
	@Override
	public OrderItemDto createOrderItem(OrderItemRequest itemRequest) {
		// TODO Auto-generated method stub
		OrderItem item = new OrderItem();
		OrderItemDto dto = new OrderItemDto();
		BeanUtils.copyProperties(itemRequest, item);
		repo.save(item);
		BeanUtils.copyProperties(item, dto);
		return dto;
	}

	@Override
	public List<OrderItemDto> fetchAllOrderItems() {
		// TODO Auto-generated method stub
		List<OrderItemDto> orders = new ArrayList<>();
		OrderItemDto item  = new OrderItemDto();
		repo.findAll().forEach( e -> {BeanUtils.copyProperties(e, item); orders.add(item);});
		return orders;
	}

	@Override
	public OrderItemDto fetchOrderItem(String pProductCode) {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public List<OrderItemDto> bookItems(List<OrderItemRequest> items) {
		OrderItemDto item  = new OrderItemDto();	
		List<OrderItemDto> orderedItems = new ArrayList<>();
	 repo.saveAll(items.stream().map(new Function<OrderItemRequest, OrderItem>() {
		    @Override
		    public OrderItem apply(OrderItemRequest s) {
		        // a simple mapping from domain to dto
		    	OrderItem r = repo.findByproductCode(s.getProductCode()).orElseThrow(()->new RuntimeException("Item Not found"));
		    	r.setQuantity(r.getQuantity() - s.getQuantity());
		        return r;
		    }
		}).collect(Collectors.toList())).forEach(orderedItem -> {BeanUtils.copyProperties(orderedItem, item); orderedItems.add(item); } );;
		return orderedItems;
	}

}
