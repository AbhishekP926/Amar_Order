package com.example.orderItem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.orderItem.Dto.OrderItemDto;
import com.example.orderItem.Dto.OrderItemRequest;

@Service
public interface OrderItemService {

	
	public OrderItemDto createOrderItem(OrderItemRequest itemRequest);
	
	public List<OrderItemDto> fetchAllOrderItems();
	
	public OrderItemDto fetchOrderItem(String pProductCode);
	
	public List<OrderItemDto> bookItems(List<OrderItemRequest> items);
	
}
