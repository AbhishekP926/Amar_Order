/**
 * 
 */
package com.example.orderItem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderItem.Dto.OrderItemDto;
import com.example.orderItem.Dto.OrderItemRequest;
import com.example.orderItem.service.OrderItemService;


/**
 * @author 34798
 *
 */
@RestController
@RequestMapping("/online/v1/orderItem")
public class OrderItemController {

	@Autowired
	private OrderItemService service;
	@PostMapping(path = "/createItem")
	public ResponseEntity<OrderItemDto> createOrderItem(@RequestBody OrderItemRequest item){
		return ResponseEntity.status(HttpStatus.OK).body(service.createOrderItem(item));
	}
	@GetMapping(path = "/fetchAllItems")
	public ResponseEntity<List<OrderItemDto>> fetchAllItems(){
		return ResponseEntity.status(HttpStatus.OK).body(service.fetchAllOrderItems());
	}
	@GetMapping(path = "/fetchItem/{productCode}")
	public ResponseEntity<OrderItemDto> fetchItems(@PathVariable String productCode){
		return ResponseEntity.status(HttpStatus.OK).body(service.fetchOrderItem(productCode));
	}
	
	@PostMapping(path = "/bookItem")
	public ResponseEntity<List<OrderItemDto>> bookItems(@RequestBody List<OrderItemRequest> items){
		
	   
	   return ResponseEntity.status(HttpStatus.OK).body(service.bookItems(items));
		 
	}
}
