package com.example.orderItem.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemDto {
	    private Long oId;
		private String productName;
		private String productCode;
		private int quantity;

}
