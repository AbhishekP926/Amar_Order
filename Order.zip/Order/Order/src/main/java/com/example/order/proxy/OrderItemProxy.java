package com.example.order.proxy;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.order.Dto.OrderItemDto;
import com.example.order.Dto.OrderItemRequest;



@FeignClient(url = "http://localhost:8090/online/v1/orderItem",name = "OrderItems")
public interface OrderItemProxy {
	@PostMapping(path="/bookItem")
	public List<OrderItemDto> createItems(@RequestBody List<OrderItemRequest> items);
	
	
}
