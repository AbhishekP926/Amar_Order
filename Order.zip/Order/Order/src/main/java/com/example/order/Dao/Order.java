package com.example.order.Dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity(name = "CUSTOMER_ORDER")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long oId;
	private String customerName;
	private String orderDate;
	@Embedded
	private ShippingAddress shippingAddress;
	@Embedded
	private List<OrderItem> orderItems;
	private BigDecimal total;
}
