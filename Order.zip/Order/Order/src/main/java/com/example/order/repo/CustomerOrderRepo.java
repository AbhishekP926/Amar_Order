package com.example.order.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.order.Dao.Order;

@Repository
public interface CustomerOrderRepo extends CrudRepository<Order, Long> {

}
