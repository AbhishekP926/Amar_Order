package com.example.order.Dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrderItemDto {
	private String productName;
	private String productCode;
	private int quantity;
}
