/**
 * 
 */
package com.example.order.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author 34798
 *
 */
@Getter
@Setter
@AllArgsConstructor
public class OrderItemRequest {
	private String productName;
	private String productCode;
	private int quantity;
}
