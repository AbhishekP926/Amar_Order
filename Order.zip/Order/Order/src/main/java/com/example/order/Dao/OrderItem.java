/**
 * 
 */
package com.example.order.Dao;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 34798
 *
 */
@Getter
@Setter
@Embeddable
public class OrderItem {
	private String productName;
	private String productCode;
	private int quantity;
}
