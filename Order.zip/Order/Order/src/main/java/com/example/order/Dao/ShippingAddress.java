package com.example.order.Dao;

import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;

@Embeddable
@Setter
@Getter
public class ShippingAddress {

	private String Line1;
	private String Line2;
	private String city;
	private String state;
	private String country;
	private int pinCode;
}
