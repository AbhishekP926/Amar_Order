package com.example.order.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order.Dao.Order;
import com.example.order.Dao.ShippingAddress;
import com.example.order.Dto.OrderDto;
import com.example.order.Dto.OrderItemRequest;
import com.example.order.proxy.OrderItemProxy;
import com.example.order.repo.CustomerOrderRepo;
import com.example.order.service.CustomerOrderService;

@Service
public class CustomerOrderServiceImpl implements CustomerOrderService {

	@Autowired
	private CustomerOrderRepo repo;
	
	@Autowired
	OrderItemProxy proxy;
	
	@Override
	public OrderDto createCustomerOrder(OrderDto pOrderDto) {
		// TODO Auto-generated method stub
		Order entity = new Order();
		ShippingAddress address = new ShippingAddress();
		entity.setShippingAddress(address);
		proxy.createItems(pOrderDto.getOrderItems().stream().map(i-> new OrderItemRequest(i.getProductName(),i.getProductCode(),i.getQuantity())).collect(Collectors.toList()));
		BeanUtils.copyProperties(pOrderDto, entity);
		BeanUtils.copyProperties(pOrderDto.getShippingAddress(), entity.getShippingAddress());
		repo.save(entity);
		BeanUtils.copyProperties(entity.getShippingAddress(), pOrderDto.getShippingAddress());
		BeanUtils.copyProperties(entity, pOrderDto);
		return pOrderDto;
	}

	@Override
	public List<OrderDto> fetchAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderDto fetchOrder() {
		// TODO Auto-generated method stub
		return null;
	}

}
