package com.example.order.Dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderDto {

	private String customerName;
	private String orderDate;
	private ShippingAddressDto shippingAddress;
	private List<OrderItemDto> orderItems;
	private BigDecimal total;
}
