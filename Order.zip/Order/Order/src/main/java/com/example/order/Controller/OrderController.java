/**
 * 
 */
package com.example.order.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.Dto.OrderDto;
import com.example.order.service.CustomerOrderService;

/**
 * @author AbhisheK
 *
 */
@RestController
@RequestMapping("/online/v1/order")
public class OrderController {

    @Autowired
	private CustomerOrderService service;	
	
	@PostMapping(path = "/createOrder")
	public ResponseEntity<OrderDto> createCustomerOrder(@RequestBody OrderDto pOrderDto){
		
//		service.createCustomerOrder(pOrderDto);
		return ResponseEntity.ok(service.createCustomerOrder(pOrderDto));
	}
	
//	public ResponseEntity<> fetchCustomerOrders(){}
}
