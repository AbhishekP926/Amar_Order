package com.example.order.Controller;

public class OrderRequest {

	
}
