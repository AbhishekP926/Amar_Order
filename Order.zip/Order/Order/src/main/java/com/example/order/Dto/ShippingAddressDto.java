package com.example.order.Dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ShippingAddressDto {
	private String Line1;
	private String Line2;
	private String city;
	private String state;
	private String country;
	private int pinCode;
}
